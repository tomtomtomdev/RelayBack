# Handoff: RelayBack — macOS menu-bar agent UI

## Overview
RelayBack is a macOS menu-bar (`MenuBarExtra`, `LSUIElement`) agent that runs a fixed
**allowlist** of commands on an unattended Mac, triggered from a private **Telegram bot**,
gated by a **TOTP arm/disarm** session, returning command output to chat. This handoff covers
the **app's UI surfaces**: the menu-bar popover (armed/disarmed), the Settings window
(Security/TOTP, Allowlist, Audit), and — for reference — the operator-facing Telegram chat
experience. Full product requirements live in `SPEC.md` / `PLAN.md` / `CLAUDE.md` (the source
documents this design was built from).

## About the design files
The file in this bundle (`RelayBack.dc.html`) is a **design reference created in HTML** — a
prototype showing intended look and behavior, **not production code to copy directly**. The
target app is a **SwiftUI macOS app** (see `SPEC.md` §7–8). The task is to **recreate these
designs natively in SwiftUI** using the architecture already specified in the spec
(`MenuBarExtra`, `@Observable` view state, the `AppCoordinator` + protocol-backed modules) —
following the project's established TDD conventions in `CLAUDE.md`. Do **not** ship HTML.

> Note: `RelayBack.dc.html` is a "Design Component" — it opens directly in a browser. The
> markup is plain inline-styled HTML; the only logic is a small generator that produces a faux
> `otpauth://` QR image for the mock. Read it for exact measurements/colors; ignore the
> `<x-dc>` / `support.js` wrapper, which is just the preview runtime.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, and layout. Recreate pixel-faithfully in
SwiftUI using native controls and SF Symbols. Where this doc specifies Inter / JetBrains Mono,
the native app should use the **system font** (SF Pro Text) and **SF Mono** respectively — they
are the macOS equivalents and were approximated in the HTML mock.

---

## Screens / Views

### 1. Menu-bar popover — DISARMED
- **Purpose:** Default resting state. Shows the agent is listening but no action can run.
- **Layout:** Fixed-width popover, **368px** wide, `background #f4f5f9`, corner radius **14px**,
  1px border `rgba(0,0,0,.08)`, shadow `0 24px 60px rgba(0,0,0,.4)`. A 18px square caret
  (rotated 45°) points up to the menu-bar icon. Vertical stack of sections separated by 1px
  `rgba(0,0,0,.07)` dividers.
- **Components:**
  - **Header row** (padding 14/16/12): app icon (26px rounded-square, radius 7px, gradient
    `155deg #4f6bff→#2aa9c9`, white broadcast glyph) + "RelayBack" (15px / 600 / `#1c1c1e`).
    Right: status pill — `rgba(120,120,128,.16)` bg, radius 20px, 8px grey dot `#8e8e93` +
    "DISARMED" (12px / 600 / `#5b5b60`, letter-spacing .03em).
  - **Locked-state card:** white, radius 10px, 1px `rgba(0,0,0,.06)`; lock icon (stroke
    `#8e8e93`) + "No actions can run" (600) + helper "Send `/arm <code>` from Telegram…"
    (13px / `#8a8a8e`), with `/arm <code>` in a mono chip (`#f0f0f3` bg).
  - **Listening row:** 8px green dot `#34c759` (pulsing) + "Listening for updates" + right-aligned
    `@relayback_bot` (mono 12px / `#8a8a8e`).
  - **Recent list:** label "RECENT" (11px / 600 / `#a0a0a6` / uppercase). Rows = time (mono 11px
    `#a0a0a6`, 38px col) + command (mono 12px) + right status. Use **amber `#ff9f0a`** for
    "rejected · disarmed", **red `#ff3b30`** for "rejected · unknown id".
  - **Footer:** "Settings" pill (gear icon) left; "Quit" (12px `#a0a0a6`) right.

### 2. Menu-bar popover — ARMED
- **Purpose:** Active session; lists what can be run and the last result.
- **Layout:** Same 368px shell as above.
- **Components:**
  - **Header status:** green pill — `rgba(52,199,89,.16)` bg, pulsing dot `#34c759`, "ARMED"
    (`#248a3d`) **plus** a mono countdown chip `4:38` (`#248a3d` on `rgba(52,199,89,.12)`,
    tabular-nums).
  - **Subtext:** "Armed by operator · idle timeout resets on each action." (12.5px `#8a8a8e`).
  - **Allowlisted actions:** label "ALLOWLISTED ACTIONS"; three white cards (radius 9px, 1px
    `rgba(0,0,0,.06)`) each = command (mono 13px / 600 / **`#0a6cff`**) + description (12.5px
    `#8a8a8e`): `/uptime` "system uptime & load", `/disk` "disk usage summary", `/whoami`
    "current user & host". Caption (with paper-plane icon): "Trigger from the Telegram chat —
    the menu shows the registry, read-only."
  - **Last result card:** dark `#0f1320`, radius 9px, mono 11.5px. `$ /uptime` (`#6f7a93`),
    `exit 0` in green `#7ee0a0`, then output lines `#cdd6e8`.
  - **Footer:** "Disarm now" (red `#ff3b30` on `rgba(255,59,48,.1)`) left; "Settings · Quit" right.

### 3. Settings window — Security (TOTP)
- **Purpose:** Generate/scan the TOTP secret; tune arming behavior.
- **Layout:** macOS window, **660px** wide, `#ececec`, radius 12px. 44px title bar
  (`linear-gradient #f6f6f6→#e9e9e9`) with three 12px traffic lights (`#ff5f57 / #febc2e /
  #28c840`) left and centered title "RelayBack Settings". Body = **176px sidebar** (`#e3e3e6`,
  1px right border) + content (`#f4f4f6`, padding 22/24).
  - **Sidebar items** (each 7/9 padding, radius 7px, icon + 13.5px label): Connection,
    Allowlist, **Security (active)**, Audit, General. Active item = `#0a6cff` bg, white text,
    shadow `0 1px 3px rgba(10,108,255,.4)`.
- **Components (Security pane):**
  - Title "TOTP arming" (18px / 700) + description (13px `#8a8a8e`).
  - **QR card:** 148×148px white, radius 12px, 11px padding, 1px `rgba(0,0,0,.08)`. Contains the
    `otpauth://` QR. (In production generate a real QR from the Keychain secret.)
  - **Secret field:** label "SECRET (BASE32)" (12px / 600 / `#6b7280`); white input row, radius
    8px, mono 13px secret + "Copy" (`#0a6cff`).
  - **Keychain assurance banner:** `rgba(52,199,89,.1)` bg, 1px `rgba(52,199,89,.25)`, lock icon
    + "Secret stored in Keychain — never on disk or in logs." (`#248a3d`).
  - **Buttons:** "Regenerate secret" (primary, `#0a6cff`, white) + "Show otpauth://" (secondary,
    white, 1px `rgba(0,0,0,.12)`).
  - **Rows:** "Idle timeout" → mono pill `5:00`; "Drift tolerance" → green toggle (ON),
    subtitle "Accept ±1 time step (RFC 6238)". Toggle = 42×25px, knob 21px.

### 4. Settings window — Allowlist
- **Purpose:** Manage authorized numeric Telegram `from.id`s.
- **Layout:** **560px** window, same chrome, title "Allowlist", content padding 20/22.
- **Components:**
  - Description: checked against `message.from.id` — never chat id; non-matches dropped silently.
  - **Member rows:** white, radius 9px. Avatar (32px circle, gradient initial) + name (13.5px /
    600) + mono id (12px `#8a8a8e`). Row 1 "Operator (me)" `id 481920774` + green "primary" badge
    (`#248a3d` on `rgba(52,199,89,.12)`). Row 2 "Backup phone" `id 729104388` + red "Remove".
  - **Add row:** white input "Add numeric id…" (mono, placeholder `#b8b8be`) + primary "Add" button.

### 5. Settings window — Audit log
- **Purpose:** Append-only record of every received command.
- **Layout:** **560px** window, title "Audit log".
- **Components:**
  - **Column header** (11px / 600 / uppercase / `#a0a0a6`): Time (62px) · from.id (108px) ·
    Action / decision (flex) · Exit (54px, right).
  - **Rows** (mono 12px, alternating `rgba(0,0,0,.025)` zebra). Examples:
    `14:32 / 481920774 / /uptime / 0` (exit green `#248a3d`); `/arm · armed` (green, exit "—");
    a **disarmed** row tinted `rgba(255,159,10,.08)` with `#b76e00` text; a **rejected** row
    tinted `rgba(255,59,48,.07)` with `#ff3b30` ("rejected · unknown id", truncated id).
  - Footer caption: "Append-only · no secrets, no full output stored."

### 6. Telegram chat (operator experience — reference only, not part of the app build)
- **Purpose:** Show the remote-control flow the app's output must render well in.
- **Layout:** iPhone frame (340×710, radius 54px, dark `#0b0d12`), dynamic island, Telegram dark
  theme (`#0e1621` chat bg, header `#17212b`).
- **Components:** Bot header (avatar + "RelayBack" + blue "BOT" badge). Message bubbles —
  operator (right) `#2b5278` mono; bot (left) `#1e2c3a`, replies with `✓ Armed for 5:00`, mono
  output blocks framed by `exit 0` (green `#7ee0a0`). Quick-command chip row (`/arm /status
  /uptime /disk`, `#5288c1`). Input bar with send button.

---

## Interactions & Behavior
- **Arm/disarm:** Popover status pill reflects live `AuthGuard` state. Arming happens via Telegram
  `/arm <totp>`; the countdown chip ticks down the idle window and **resets on each authorized
  action**. Auto-disarm on timeout or `/disarm`.
- **Pulsing dot:** "listening"/"armed" indicators use a subtle scale+opacity pulse
  (`50%` keyframe → opacity .35, scale .82, ~1.8s ease-in-out). In SwiftUI use a repeating
  `.opacity`/`.scaleEffect` animation.
- **Read-only action list:** popover lists the registry; it does **not** execute on click
  (execution path is Telegram-only in v1).
- **Settings nav:** sidebar item selection swaps the content pane (standard macOS settings).
- **Copy / Regenerate / Reveal:** copy secret to pasteboard; regenerate writes a new Keychain
  secret and refreshes the QR; token field is masked with a reveal affordance.
- **Audit:** newest-first, append-only, color-coded by decision/exit.

## State Management
Per `SPEC.md` §7. Key view state (drive with `@Observable`):
- `armState: .disarmed | .armed(expiresAt:)` — derives the pill + countdown.
- `remainingArmedSeconds` — ticked from a `Clock`; formats `m:ss`.
- `actions: [Action]` (command, description, executable path, args, timeout) from `ActionRegistry`.
- `lastResult: CommandResult?` (exit code, stdout, stderr) for the popover.
- `recentAudit: [AuditEntry]` (time, fromId, action/decision, exitCode).
- `allowlist: [AllowedUser]` (id, label, isPrimary).
- Settings: `botTokenMasked`, `totpSecretBase32`, `otpauthURL`, `idleTimeout`, `driftTolerance`,
  `launchAtLogin`. Secrets come from `KeychainStore`, never persisted elsewhere.
- Connection state: `.connected(botUsername:)` / `.error`.

## Design Tokens

**Colors**
- Popover surface `#f4f5f9`; settings window `#ececec` / content `#f4f4f6` / sidebar `#e3e3e6`.
- Card white `#ffffff`; dividers `rgba(0,0,0,.06–.08)`.
- Text: primary `#1c1c1e`; secondary `#8a8a8e`; tertiary/labels `#a0a0a6`; sidebar text `#3a3a3c`.
- Accent blue `#0a6cff` (commands, primary buttons, active nav).
- Armed/success green `#34c759`, dark text `#248a3d`, terminal green `#7ee0a0`.
- Disarmed grey `#8e8e93` (dot) / `#5b5b60` (text).
- Warning amber `#ff9f0a` / text `#b76e00`; danger red `#ff3b30`.
- Dark result card `#0f1320`; brand gradient `155deg #4f6bff → #2aa9c9`.
- Traffic lights `#ff5f57 / #febc2e / #28c840`.
- Telegram: chat `#0e1621`, header/bars `#17212b`, out-bubble `#2b5278`, in-bubble `#1e2c3a`,
  accent `#5288c1`.
- Desktop wallpaper (board only) `165deg #3a6ea5 → #2c4d7a → #23708a`.

**Typography** — System (SF Pro Text) for UI; **SF Mono** for commands, ids, output, countdowns.
Sizes: titles 18px/700; body 13.5–14px; secondary 12.5–13px; labels 11px/600 uppercase
(letter-spacing .05–.06em); mono output 11.5–12px.

**Radius** — popover 14; window 12; cards 9–10; chips/buttons 7–8; pills 20; QR card 12.

**Shadows** — popover `0 24px 60px rgba(0,0,0,.4)`; window `0 24px 60px rgba(0,0,0,.42)`;
active nav `0 1px 3px rgba(10,108,255,.4)`.

**Spacing** — popover section padding ~14–18px; settings content 20–24px; gaps 6–14px.

## Assets
- **App icon:** rounded-square, brand gradient, white "broadcast waves + dot + lock" glyph —
  drawn inline as SVG in the mock; produce a real app icon set for shipping.
- **QR code:** placeholder/faux QR in the mock; generate a real QR from the live `otpauth://`
  URL at runtime.
- **Icons:** approximated as inline SVG; **replace with SF Symbols** in SwiftUI
  (`gearshape`, `lock.fill`, `wifi`, `person.2`, `checkmark.shield`, `doc.text`,
  `paperplane.fill`, etc.).
- No raster image assets are required from this bundle.

## Files
- `RelayBack.dc.html` — the full design board (all six surfaces). Open in a browser to inspect.
- Source-of-truth product docs (in the project `uploads/`, not duplicated here):
  `SPEC.md`, `PLAN.md`, `PROGRESS.md`, `CLAUDE.md`.
